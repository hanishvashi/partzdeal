

<?php $__env->startSection('content'); ?>
<div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard Office Address -->
                        <div class="section-padding add-product-1">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="add-product-box">
                                    <div class="product__header"  style="border-bottom: none;">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Payment Informations</h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Payment Settings <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Payment Informations
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>
                                    </div>
                                        <hr>
                                        <form class="form-horizontal" action="<?php echo e(route('admin-gs-paymentsup')); ?>" method="POST">
                                          <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                          <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                          <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="disable/enable_about_page">Guest Checkout:</label>
                                            <div class="col-sm-3" style="margin-top: 6px;">
                                                        <span class="dropdown">
                                            <button id="Vendor" class="btn btn-<?php echo e($gs->guest_checkout == 1 ? 'primary':'danger'); ?> product-btn dropdown-toggle btn-xs" type="button" data-toggle="dropdown" style="font-size: 14px;"><?php echo e($gs->guest_checkout == 1 ? 'Activated':'Deactivated'); ?>

                                                <span class="caret"></span></button>
                                                        <ul class="dropdown-menu">
                                                            <li><a href="<?php echo e(route('admin-gs-guest',1)); ?>">Active</a></li>
                                                            <li><a href="<?php echo e(route('admin-gs-guest',0)); ?>">Deactive</a></li>
                                                        </ul>
                                                        </span>
                                            </div>
                                          </div>

                      <div class="form-group">

                      <label class="control-label col-sm-4" for="paypal_type"><?php echo e(__('Paypal')); ?></label>
                      <div class="col-sm-6">
                        <span class="dropdown">
            <button id="paypal_type" class="btn btn-<?php echo e($gs->paypal_check == 1 ? 'primary':'danger'); ?> product-btn dropdown-toggle btn-xs" type="button" data-toggle="dropdown" style="font-size: 14px;"><?php echo e($gs->paypal_check == 1 ? 'Activated':'Deactivated'); ?>

                <span class="caret"></span></button>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('admin-gs-paypal',1)); ?>">Active</a></li>
                            <li><a href="<?php echo e(route('admin-gs-paypal',0)); ?>">Deactive</a></li>
                        </ul>
                        </span>
                      </div>
                      </div>


                        <div class="form-group">
                          <label class="control-label col-sm-4" for="paypal_text"><?php echo e(__('Paypal Email')); ?></label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control" placeholder="<?php echo e(__('Paypal Email')); ?>" name="paypal_business" value="<?php echo e($gs->paypal_business); ?>" required="">
                          </div>
                        </div>

                        <div class="form-group">
                          <label class="control-label col-sm-4" for="paypal_text">Paypal Text *</label>
                          <div class="col-sm-6">
                            <textarea class="form-control" name="paypal_text" id="paypal_text" placeholder="<?php echo e(__('Paypal Text')); ?>"><?php echo e($gs->paypal_text); ?></textarea>
                          </div>
                        </div>
<hr>

                                          <div class="form-group">
                                            <label class="control-label col-sm-4" for="website_title">Currency Format *</label>
                                            <div class="col-sm-6">
                                              <select id="website_title" class="form-control" name="sign">
                                                <option value="0" <?php echo e($data->sign == 0 ? 'selected':''); ?>>Before Price</option>
                                                <option value="1" <?php echo e($data->sign == 1 ? 'selected':''); ?>>After Price</option>
                                              </select>
                                            </div>
                                          </div>
                                          <div class="form-group" style="display:none;">
                                            <label class="control-label col-sm-4" for="phone9">Withdraw Fee *<span>Withdraw Fee(Withdraw Amount + Withdraw Fee)</span></label>
                                            <div class="col-sm-6">
                                              <input name="withdraw_fee" id="phone9" class="form-control" placeholder="Withdraw Fee" type="text" value="<?php echo e($data->withdraw_fee); ?>" required="">
                                            </div>
                                          </div>
                                          <div class="form-group" style="display:none;">
                                            <label class="control-label col-sm-4" for="phone4">Withdraw Charge(%) *<span>Withdraw Charge(Withdraw Amount + Withdraw Charge(%))</span></label>
                                            <div class="col-sm-6">
                                              <input name="withdraw_charge" id="phone4" class="form-control" placeholder="Withdraw Charge" type="text" value="<?php echo e($data->withdraw_charge); ?>" required="">
                                            </div>
                                          </div>
                                          <div class="form-group" style="display:none;">
                                            <label class="control-label col-sm-4" for="phone5">Fixed Commission *<span>Fixed Commission Charge(Product Price + Commission)</span></label>
                                            <div class="col-sm-6">
                                              <input name="fixed_commission" id="phone5" class="form-control" placeholder="Fixed Commission" type="text" value="<?php echo e($data->fixed_commission); ?>" required="">
                                            </div>
                                          </div>
                                          <div class="form-group" style="display:none;">
                                            <label class="control-label col-sm-4" for="phone6">Percentage Commission(%) *<span>Percentage Commission Charge(Product Price + Commission(%))</span></label>
                                            <div class="col-sm-6">
                                              <input name="percentage_commission" id="phone6" class="form-control" placeholder="Percentage Commission" type="text" value="<?php echo e($data->percentage_commission); ?>" required="">
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <label class="control-label col-sm-4" for="phone7">Tax(%) *<span>Tax Fee(Product Price + Tax(%))</span></label>
                                            <div class="col-sm-6">
                                              <input name="tax" id="phone7" class="form-control" placeholder="Tax" type="text" value="<?php echo e($data->tax); ?>" required="">
                                            </div>
                                          </div>
                                        <div class="form-group" style="display:none;">
                                            <label class="control-label col-sm-4" for="disable/enable_about_page">Multiple Shipping *</label>
                                            <div class="col-sm-3">
                                                <label class="switch">
                                                  <input type="checkbox" name="multiple_ship" value="1" <?php echo e($data->multiple_ship==1?"checked":""); ?>>
                                                  <span class="slider round"></span>
                                                </label>
                                            </div>
                                          </div>
                                          <div class="form-group" style="display:none;">
                                            <label class="control-label col-sm-4" for="phone8">Shipping Cost *<span>(Total Amount + Shipping Cost)</span></label>
                                            <div class="col-sm-6">
                                              <input name="ship" id="phone8" class="form-control" placeholder="Shipping Cost" type="text" value="<?php echo e($data->ship); ?>" required="">
                                            </div>
                                          </div>
                                        <div class="form-group" style="display:none;">
                                            <label class="control-label col-sm-4" for="disable/enable_about_page">Shipping Information For Vendor *</label>
                                            <div class="col-sm-3">
                                                <label class="switch">
                                                  <input type="checkbox" name="ship_info" value="1" <?php echo e($data->ship_info==1?"checked":""); ?>>
                                                  <span class="slider round"></span>
                                                </label>
                                            </div>
                                          </div>
                                            <hr>
                                            <div class="add-product-footer">
                                                <button name="addProduct_btn" type="submit" class="btn add-product_btn">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard Office Address -->
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/admin/js/nicEdit.js')); ?>"></script>
<script type="text/javascript">
//<![CDATA[
        bkLib.onDomLoaded(function() { nicEditors.allTextAreas() });
  //]]>
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/partzdeal/project/resources/views/admin/generalsetting/payments.blade.php ENDPATH**/ ?>