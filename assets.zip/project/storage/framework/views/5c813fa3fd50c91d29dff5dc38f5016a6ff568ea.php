<div class="payment-information">
  <h4 class="title">Payment Info</h4>
  <div class="row">
    <div class="col-lg-12">
      <div class="nav flex-column"  role="tablist" aria-orientation="vertical">
        <a class="nav-link payment" data-val="" data-show="no" data-form="<?php echo e(route('payu.submit')); ?>" data-href="<?php echo e(route('front.load.payment',['slug1' => 'payu','slug2' => 0])); ?>" id="v-pills-tab1-tab" data-toggle="pill" href="#v-pills-tab1" role="tab" aria-controls="v-pills-tab1" aria-selected="true">
        <div class="icon"><span class="radio"></span></div>
        <p>PayuMoney <small></small></p>
        </a>
      </div>
    </div>

  </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/partzdeal/project/resources/views/load/payment-india.blade.php ENDPATH**/ ?>