
<?php $__env->startSection('content'); ?>
     <section class="customer-profile">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard add-product-1 area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="product__header">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Change Password</h2>
                                                </div>
                                            </div>
                                             
                                        </div>   
                                    </div>
                                    <form class="form-horizontal" action="<?php echo e(route('customer-reset-submit')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="admin_current_password"><?php echo e($lang->cp); ?> *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" name="cpass" id="admin_current_password" placeholder="<?php echo e($lang->cp); ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="admin_new_password"><?php echo e($lang->np); ?> *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" name="newpass" id="admin_new_password" placeholder="<?php echo e($lang->np); ?>" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-4" for="admin_retype_password"><?php echo e($lang->rnp); ?> *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" name="renewpass" id="admin_retype_password" placeholder="<?php echo e($lang->rnp); ?>" required>
                                            </div>
                                        </div>
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn add-product_btn">Change Password</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard add-product-1 area -->
                </div>
            </div>
        </div>
    </section>
    <!-- Ending of Account Dashboard area -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/partzdeal/public_html/project/resources/views/user/customer-reset.blade.php ENDPATH**/ ?>