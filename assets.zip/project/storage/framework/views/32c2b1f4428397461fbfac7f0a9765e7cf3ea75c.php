<div class="col-md-7 col-lg-6 p-3 description_column">
    <div id="sticky-anchor"></div>
    <div id="sidebar" class="inner_detail">
      <?php if(strlen($product->name) > 40): ?>
        <h3 class="productDetails-header"><?php echo e($product->name); ?></h3>
      <?php else: ?>
      <h3 class="productDetails-header mb-3"><?php echo e($product->name); ?></h3>
      <?php endif; ?>
      <?php if(!empty($brand_name)): ?>
      <h6 class="mb-1">Brand : <?php echo e($brand_name); ?></h6>
      <?php endif; ?>
      <h6 class="mb-1">Product SKU: <?php echo e($product->sku); ?></h6>
        <?php if($product->user_id != 0): ?>

          <?php if(isset($product->user)): ?>
        <div class="productDetails-header-info">

        <div class="product-headerInfo__title">
          <?php echo e($lang->shop_name); ?>: <a style=" color:<?php echo e($gs->colors == null ? '#337ab7':$gs->colors); ?>;" href="<?php echo e(route('front.vendor',str_replace(' ', '-',($product->user->shop_url)))); ?>"><?php echo e($product->user->shop_name); ?></a>
        </div>
        </div>
<?php endif; ?>
<?php else: ?>


        <?php endif; ?>
          <?php if($product->ship != null): ?>
    <div class="productDetails-header-info">
        <div class="product-headerInfo__title">
          <?php echo e($lang->shipping_time); ?>: <span style="font-weight: 400;"><?php echo e($product->ship); ?>.</span>
        </div>
    </div>
                  <?php endif; ?>

          <?php
            $stk = (string)$product->stock;
          ?>


        <p class="productDetails-reviews">
            <div class="ratings">
              <div class="empty-stars"></div>
              <div class="full-stars" style="width:<?php echo e(App\Review::ratings($product->id)); ?>%"></div>
            </div>
          <span><?php echo e(count($product->reviews)); ?> <?php echo e($lang->dttl); ?></span>
        </p>
        <?php if($gs->sign == 0): ?>
        <h3 class="productDetails-price d-none d-md-block">
        <?php
        $product_price = $product->cprice;
        ?>
        <?php echo e($curr->sign); ?><span class="pricetxts"><?php echo e(number_format($product->cprice, 2)); ?></span>

        <?php if($product->pprice != null): ?>
         <span><del><?php echo e($curr->sign); ?><?php echo e(round($product->pprice * $curr->value,2)); ?></del></span>
        <?php endif; ?>
       </h3>
<input type="hidden" id="product_price" value="<?php echo e($product_price); ?>"/>
       <?php else: ?>
       <h3 class="productDetails-price">

<?php
$product_price = $product->cprice;
?>
          <?php echo e($curr->sign); ?><span class="pricetxts"><?php echo e(number_format($product->cprice, 2)); ?></span>
<?php echo e($curr->sign); ?>

        <?php if($product->pprice != null): ?>
         <span><del><?php echo e(round($product->pprice * $curr->value,2)); ?><?php echo e($curr->sign); ?></del></span>
        <?php endif; ?>
        </h3>
<input type="hidden" id="product_price" value="<?php echo e($product_price); ?>"/>
       <?php endif; ?>

<?php if(!empty($product->size)){?>
<input type="hidden" id="product_option_size" value="0"/>
<?php }else{?>
<input type="hidden" id="product_option_size" value="1"/>
<?php }?>

        <?php if(!empty($product->size)): ?>
<div class="product-size">
<p class="title"><?php echo e($lang->doo); ?> :</p>
<ul class="siz-list">
<?php
$is_first = true;
?>
<?php $__currentLoopData = $size; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="<?php echo e($is_first ? '' : ''); ?>">
<span class="box"><?php echo e($data1); ?>

<input type="hidden" class="size" value="<?php echo e($data1); ?>">
<input type="hidden" class="size_qty" value="<?php echo e($size_qty[$key]); ?>">
<input type="hidden" class="size_key" value="<?php echo e($key); ?>">
<input type="hidden" class="size_price" value="<?php echo e(round($size_price[$key] * $curr->value,2)); ?>">
</span>
</li>
<?php
$is_first = false;
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<li>
</ul>
</div>
<?php endif; ?>

<?php if(!empty($product->color)){?>
<input type="hidden" id="product_option_color" value="0"/>
<?php }else{?>
<input type="hidden" id="product_option_color" value="1"/>
<?php }?>

          <?php if(!empty($product->color)): ?>
<div class="product-color">
<p class="title"><?php echo e($lang->colors); ?> :</p>
<ul class="color-list">
<?php
$is_first = true;
?>
<?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li class="<?php echo e($is_first ? '' : ''); ?>">
<span class="box" data-color="<?php echo e($color[$key]); ?>" style="background-color: <?php echo e($color[$key]); ?>"></span>
</li>
<?php
$is_first = false;
?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
<?php endif; ?>
<?php if(!empty($tier_prices)){?>
<ul class="tier-prices product-pricing">
<?php foreach($tier_prices as $key=> $tierprice){
if($product->user_id != 0){
  $group_price = $tierprice['price'] + $gs->fixed_commission + ($tierprice['price']/100) * $gs->percentage_commission ;
}else{
  $group_price = $tierprice['price'];
}
?>
<li class="tier-price tier-<?php echo $key;?>">
Buy <?php echo round($tierprice['price_qty'],0);?> or more for <span class="price"><?php echo e($curr->sign); ?><?php echo e(number_format($group_price, 2)); ?></span> each
</li>
<?php }?>
</ul>
<?php }?>
        <div class="productDetails-quantity">
          <p><?php echo e($lang->cquantity); ?></p>
          <input type="hidden" id="stock" value="<?php echo e($product->stock); ?>">
          <span class="quantity-btn" id="qsub"><i class="fa fa-minus"></i></span>
          <span id="qval"><?php echo e($product->min_qty); ?></span>
          <span class="quantity-btn" id="qadd"><i class="fa fa-plus"></i></span>
          <!--<span style="padding-left: 5px; border: none; font-weight: 700; font-size: 15px;"><?php echo e($product->measure); ?></span>-->
          <span style="padding-left: 5px; border: none; font-weight: 700; font-size: 15px; width: 100px;">In Stock</span>
        </div>

        <?php if($stk == "0"): ?>
        <a class="productDetails-addCart-btn addCart_btn d-none d-md-inline-block" style="cursor: no-drop;;">
          <i class="fa fa-cart-plus"></i> <span><?php echo e($lang->dni); ?></span>
        </a>
        <?php else: ?>
        <a class="productDetails-addCart-btn addCart_btn addtocartajax d-none d-md-inline-block" id="addcrt" style="cursor: pointer;">
          <i class="fa fa-cart-plus"></i> <span><?php echo e($lang->hcs); ?></span>
        </a>
        <?php endif; ?>
          <input type="hidden" id="pid" value="<?php echo e($product->id); ?>">
<?php if($product->size_guide != null): ?>
<div class="col-12 p-0 mt-3 d-none d-md-block">
<a href="#sizeguideModel" data-toggle="modal" data-target="#sizeguideModel">Size Guide</a>
</div>
<?php endif; ?>





    <a style="cursor: pointer;" data-productid="<?php echo e($product->id); ?>" data-productsku="<?php echo e($product->sku); ?>" data-productname="<?php echo e($product->name); ?>" class="productDetails-addCart-btn addCart_btn no-wish enqbtn" data-toggle="modal" data-target="#InquiryModal"><span>Enquire Now</span></a>


        <div class="custom-tab d-none d-lg-block">
        <div class="row m-0 pb-1">
            <div class="col-12">
                <h2 class="heading_three mb-4"><?php echo e($lang->ddesc); ?></h2>
                <?php if(strlen($product->description) > 70): ?>
                    <p <?php echo $lang->rtl == 1 ? 'dir="rtl"' : ''; ?>><?php echo $product->description; ?></p>
                <?php else: ?>
                    <p <?php echo $lang->rtl == 1 ? 'dir="rtl"' : ''; ?>><?php echo $product->description; ?></p>
                 <?php endif; ?>
            </div>

            <div class="col-12">
                <?php if(Auth::guard('user')->check()): ?>

                    <?php if(Auth::guard('user')->user()->orders()->count() > 0): ?>
                    <h1 class="heading_three mb-4"><?php echo e($lang->fpr); ?></h1>
                    <hr>
                    <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="product-reviews">
                        <div class="review-star">
                          <div class='starrr' id='star1'></div>
                            <div>
                                <span class='your-choice-was' style='display: none;'>
                                  <?php echo e($lang->dofpl); ?>: <span class='choice'></span>.
                                </span>
                            </div>
                        </div>
                    </div>
                    <form class="product-review-form" action="<?php echo e(route('front.review.submit')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="user_id" value="<?php echo e(Auth::guard('user')->user()->id); ?>">
                        <input type="hidden" name="rating" id="rate" value="5">
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                        <div class="form-group">
                            <textarea name="review" id="" rows="5" placeholder="<?php echo e($lang->suf); ?>" class="form-control" style="resize: vertical;" required></textarea>
                        </div>
                        <div class="form-group text-center">
                            <input name="btn" type="submit" class="btn-review" value="Submit Review">
                        </div>
                    </form>
                    <?php else: ?>
                    <h3 class="heading_three mb-3"><?php echo e($lang->product_review); ?>.</h3>
                    <?php endif; ?>
                    <hr>
                      <h1 class="heading_three mb-3"><?php echo e($lang->dttl); ?>: </h1>
                    <hr>
                    <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="review-rating-description">
                            <div class="row">
                              <div class="col-md-3 col-sm-3">
                                <p><?php echo e($review->user->name); ?></p>
                                <p class="product-reviews">
                                  <div class="ratings">
                                    <div class="empty-stars"></div>
                                    <div class="full-stars" style="width:<?php echo e($review->rating*20); ?>%"></div>
                                  </div>
                                </p>
                                <p><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $review->review_date)->diffForHumans()); ?></p>
                              </div>
                              <div class="col-md-9 col-sm-9">
                                <p><?php echo e($review->review); ?></p>
                              </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <h4><?php echo e($lang->md); ?></h4>
                            </div>
                        </div>
                        <?php endif; ?>

                    <?php else: ?>

                        <h2 class="heading_three mb-4"><?php echo e($lang->dttl); ?></h2>
                        <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="review-rating-description">
                            <div class="row">
                              <div class="col-12 col-md-3">
                                <p><?php echo e($review->user->name); ?></p>
                                <p class="product-reviews">
                                  <div class="ratings">
                                    <div class="empty-stars"></div>
                                    <div class="full-stars" style="width:<?php echo e($review->rating*20); ?>%"></div>
                                  </div>
                              </p>
                                <p><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $review->review_date)->diffForHumans()); ?></p>
                              </div>
                              <div class="col-12 col-md-9">
                                <p><?php echo e($review->review); ?></p>
                              </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <h4><?php echo e($lang->md); ?></h4>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

        </div>
    </div>
        </div>
    </div>
<?php /**PATH H:\wamp64\www\durapart\project\resources\views/includes/product-info.blade.php ENDPATH**/ ?>