<div class="login_form d-none mb-2">
<h5 class="title">Login Details</h5>
<div class="row">
<div class="col-lg-6">
<input type="email" id="user_email_address" class="form-control" name="user_email_address" placeholder="Enter Your Email" value="">
</div>
<div class="col-lg-6">
<input type="password" id="user_password" class="form-control" name="user_password" placeholder="Enter Your Password" value=""/>
</div>
<div class="col-lg-12  mt-3">
<div class="bottom-area paystack-area-btn">
<button type="button" id="customer_login" class="button">Login</button>
</div>
</div>
</div>
</div>
<?php /**PATH /home/partzdeal/public_html/project/resources/views/includes/ajax-login-form.blade.php ENDPATH**/ ?>