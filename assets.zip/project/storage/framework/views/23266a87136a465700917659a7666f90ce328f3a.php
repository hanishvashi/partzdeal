<h5><?php echo e($product->name); ?></h5>
<p class="mb-2 text-muted text-uppercase small">Brand : <?php echo e($brand_name); ?></p>
<p class="mb-2 text-muted text-uppercase small">Product SKU: <?php echo e($product->sku); ?></p>
<p class="productDetails-reviews">
    <div class="ratings">
      <div class="empty-stars"></div>
      <div class="full-stars" style="width:<?php echo e(App\Review::ratings($product->id)); ?>%"></div>
    </div>
  <span><?php echo e(count($product->reviews)); ?> <?php echo e($lang->dttl); ?></span>
</p>
<?php
$product_price = $product->cprice;
?>
<p><span class="mr-1"><strong><?php echo e($curr->sign); ?><?php echo e(number_format($product->cprice, 2)); ?></strong></span></p>
<?php if(!empty($product->size)){?>
<input type="hidden" id="product_option_size" value="0"/>
<?php }else{?>
<input type="hidden" id="product_option_size" value="1"/>
<?php }?>
<?php if(!empty($product->color)){?>
<input type="hidden" id="product_option_color" value="0"/>
<?php }else{?>
<input type="hidden" id="product_option_color" value="1"/>
<?php }?>

<?php if(!empty($tier_prices)){?>
<ul class="tier-prices product-pricing">
<?php foreach($tier_prices as $key=> $tierprice){
if($product->user_id != 0){
  $group_price = $tierprice['price'] + $gs->fixed_commission + ($tierprice['price']/100) * $gs->percentage_commission ;
}else{
  $group_price = $tierprice['price'];
}
?>
<li class="tier-price tier-<?php echo $key;?>">
Buy <?php echo round($tierprice['price_qty'],0);?> or more for <span class="price"><?php echo e($curr->sign); ?><?php echo e(number_format($group_price, 2)); ?></span> each
</li>
<?php }?>
</ul>
<?php }?>
<input type="hidden" id="product_price" value="<?php echo e($product_price); ?>"/>
<hr>
<?php
  $stk = (string)$product->stock;
?>
<input type="hidden" id="pid" value="<?php echo e($product->id); ?>">

<div class="table-responsive">
  <table class="table table-sm table-borderless">
    <tbody>
      <tr>
        <td class="pl-0">
          <div class="productDetails-quantity">
          <p><?php echo e($lang->cquantity); ?></p>
          <input type="hidden" id="stock" value="<?php echo e($product->stock); ?>">
          <span class="quantity-btn" id="qsub"><i class="fa fa-minus"></i></span>
          <span id="qval"><?php echo e($product->min_qty); ?></span>
          <span class="quantity-btn" id="qadd"><i class="fa fa-plus"></i></span>
          <!--<span style="padding-left: 5px; border: none; font-weight: 700; font-size: 15px;"><?php echo e($product->measure); ?></span>-->
          <span style="padding-left: 5px; border: none; font-weight: 700; font-size: 15px; width: 100px;">In Stock</span>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
</div>
<?php if($stk == "0"): ?>
<a class="productDetails-addCart-btn addCart_btn d-none d-md-inline-block" style="cursor: no-drop;;">
<i class="fa fa-cart-plus"></i> <span><?php echo e($lang->dni); ?></span>
</a>
<?php else: ?>
<button type="button" class="productDetails-addCart-btn addCart_btn addtocartajax btn btn-light btn-md mr-1 mb-2" id="addcrt" style="cursor: pointer;">
<i class="fa fa-cart-plus"></i> <span><?php echo e($lang->hcs); ?></span>
</button>
<?php endif; ?>
<button type="button" data-productid="<?php echo e($product->id); ?>" data-productsku="<?php echo e($product->sku); ?>" data-productname="<?php echo e($product->name); ?>" class="productDetails-addCart-btn addCart_btn no-wish enqbtn btn btn-light btn-md mr-1 mb-2" data-toggle="modal" data-target="#InquiryModal"><i class="fa fa-info"></i> <span>Enquire Now</span></button>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/partzdeal/project/resources/views/includes/product-details.blade.php ENDPATH**/ ?>