      <?php
        $user_notff = App\Notification::where('user_id','!=',null)->orWhere('vendor_id','!=',null)->get();
        if($user_notff->count() > 0){
          foreach($user_notff as $notf){
            $notf->is_read = 1;
            $notf->update();
          }
        }
      ?>   
                                                            <div class="profile-wishlist-title">
                                                                <h5>New Notification(s).</h5>
                                                                <?php if($user_notff->count() > 0): ?>
                                                                <p style="cursor: pointer;" id="user_clear">Clear All</p>
                                                                <?php endif; ?>
                                                            </div>
                                                            
                                                              <?php if($user_notff->count() > 0): ?>
                                                              <?php $__currentLoopData = $user_notff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <?php if($notf->user_id != null): ?>
                                                              <div class="single-wishlist-area">
                                                               <div class="wishlist-img">
                                                                    <i class="fa fa-heart"></i>
                                                               </div>
                                                               <div class="single-wishlist-text">
                                                                   <h5><a href="<?php echo e(route('admin-user-show',$notf->user_id)); ?>" style="color: #333;">A New User Has Registered.</a></h5>
                                                                   <p><?php echo e($notf->created_at->diffForHumans()); ?></p>
                                                               </div>
                                                              </div>
                                                              <?php else: ?>
                                                              <div class="single-wishlist-area">
                                                               <div class="wishlist-img">
                                                                    <i class="fa fa-heart"></i>
                                                               </div>
                                                               <div class="single-wishlist-text">
                                                                   <h5><a href="<?php echo e(route('admin-vendor-show',$notf->vendor_id)); ?>" style="color: #333;">A User Has applied for Vendor.</a></h5>
                                                                   <p><?php echo e($notf->created_at->diffForHumans()); ?></p>
                                                               </div>
                                                              </div>
                                                              <?php endif; ?>
                                                              
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                              <?php else: ?>
                                                              <div class="single-wishlist-area">
                                                              <h5>No New Notification(s).</h5>
                                                              </div>
                                                              <?php endif; ?><?php /**PATH /home/partzdeal/public_html/project/resources/views/user_notf.blade.php ENDPATH**/ ?>