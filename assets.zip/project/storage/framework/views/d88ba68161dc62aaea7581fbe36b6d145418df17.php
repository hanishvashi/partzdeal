<div class="packeging-area">
    <h4 class="title">Shipping Methods</h4>
  <?php $__currentLoopData = $shipping_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($data->carrier_title=='Standard'){
    $fixedShipping	= $data->shipping_price;
    $shippingPer = $data->shipping_percentage;
      if($totalPrice<10000){
      $shippingCharge = ceil(($totalPrice*$shippingPer)/100);
      /*if($shippingCharge < $fixedShipping) {
      $shippingCharge = $fixedShipping;
      }*/
      $shippingChargeInEuro = $shippingCharge;
      }else{
      //add shipping price as free for order above 50
      $shippingChargeInEuro = 0;
      }

    ?>
    <div class="radio-design">
        <input type="radio" class="shipping" data-id="<?php echo e($data->id); ?>" data-title="<?php echo e($data->carrier_title); ?>" id="free-shepping-<?php echo e($data->id); ?>" name="shipping" value="<?php echo e(round($shippingChargeInEuro * $curr->value,2)); ?>" <?php echo e(($loop->first) ? 'checked' : ''); ?>>
        <span class="checkmark"></span>
        <label for="free-shepping-<?php echo e($data->id); ?>">
            <?php echo e($data->carrier_title); ?>

            <?php if($shippingChargeInEuro != 0): ?>
            + <?php echo e($curr->sign); ?><?php echo e(round($shippingChargeInEuro * $curr->value,2)); ?>

            <?php else: ?>
            <?php echo e($curr->sign); ?><?php echo e(round($shippingChargeInEuro * $curr->value,2)); ?>

            <?php endif; ?>
            <small><?php echo e($data->shipping_text); ?></small>
        </label>
    </div>
  <?php }elseif($data->carrier_title=='Priority'){
    $fixedShipping	= $data->shipping_price;
    $shippingPer = $data->shipping_percentage;
      if($totalPrice<50){
      $shippingCharge = ceil(($totalPrice*$shippingPer)/100);
      if($shippingCharge < $fixedShipping) {
      $shippingCharge = $fixedShipping;
       }
      $shippingChargeInEuro = $shippingCharge;
      }else{
        $shippingCharge = ceil(($totalPrice*$shippingPer)/100);
        //add shipping price as free for order above 50
        $shippingChargeInEuro = $shippingCharge;
      }
    ?>
    <div class="radio-design">
        <input type="radio" data-id="<?php echo e($data->id); ?>" class="shipping" id="free-shepping-<?php echo e($data->id); ?>" data-title="<?php echo e($data->carrier_title); ?>" name="shipping" value="<?php echo e(round($shippingChargeInEuro * $curr->value,2)); ?>" <?php echo e(($loop->first) ? 'checked' : ''); ?>>
        <span class="checkmark"></span>
        <label for="free-shepping-<?php echo e($data->id); ?>">
            <?php echo e($data->carrier_title); ?>

            <?php if($shippingChargeInEuro != 0): ?>
            + <?php echo e($curr->sign); ?><?php echo e(round($shippingChargeInEuro * $curr->value,2)); ?>

            <?php else: ?>
            <?php echo e($curr->sign); ?><?php echo e(round($shippingChargeInEuro * $curr->value,2)); ?>

            <?php endif; ?>
            <small><?php echo e($data->shipping_text); ?></small>
        </label>
    </div>
  <?php }?>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php /**PATH /home/partzdeal/public_html/project/resources/views/load/india-shipping-method.blade.php ENDPATH**/ ?>