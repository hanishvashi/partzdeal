<div class="product-filter-option">
<!--<h2 class="filter-title"><?php echo e($lang->doci); ?></h2>-->
<h4 class="heading_three mb-4 pb-2 pt-2 pr-2 pl-2">Categories</h4>
<ul style="direction: ltr;">
<?php 
$x=0;
 ?>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<?php if(count($ctgry['childcategories']) > 0): ?>
<span href="#filter<?php echo e(++$x); ?>" aria-expanded="false" data-toggle="collapse">
&nbsp;<i class="fa fa-plus"></i><i class="fa fa-minus"></i>&nbsp;&nbsp;&nbsp;
<?php else: ?>

<?php endif; ?>
</span>
<a href="<?php echo e(route('front.page',['slug' => $ctgry['cat_slug']])); ?>"><?php echo e($ctgry['cat_name']); ?></a>
<?php if(count($ctgry['childcategories']) > 0): ?>
<ul id="filter<?php echo e($x); ?>" class="collapse">
<?php $__currentLoopData = $ctgry['childcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subctgry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
<a href="<?php echo e(route('front.subcategory',['slug1'=>$ctgry['cat_slug'],'slug2'=>$subctgry['cat_slug']])); ?>"><?php echo e($subctgry['cat_name']); ?></a>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php endif; ?>
</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</div>
