<!--  Starting of product detail carousel area   -->
<div id="home_products" class="section-padding productDetails-carousel-wrap">
  <div class="container-fluid">
    <div class="row product_list">
      <div class="col-lg-12">
        <div class="section-title mb-4">
          <h2 class="heading_two"><?php echo e($lang->amf); ?></h2>
        </div>
      </div>
      <div class="col-lg-12">
        <div class="owl-carousel product_slider slider">
  <?php $__currentLoopData = $relatedproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fprod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
  $name = str_replace(" ","-",$fprod->name);
  ?>
        <div class="slide">

        <div class="card">
        <div class="card-body">
        <a href="<?php echo e(route('front.page',['slug' => $fprod->slug])); ?>">
        <div class="card-img-actions"> <img src="<?php echo e(asset('assets/images/'.$store_code.'/products/thumb_'.$fprod->photo)); ?>" class="card-img img-fluid" alt=""> </div>
        </a>
        <input type="hidden" value="<?php echo e($fprod->id); ?>">
        </div>
        <div class="card-body bg-light text-center">
        <div class="mb-2">
        <h6 class="font-weight-semibold mb-2"> <a href="<?php echo e(route('front.page',['slug' => $fprod->slug])); ?>" class="text-default mb-2" data-abc="true"><?php echo e(strlen($fprod->name) > 65 ? substr($fprod->name,0,65)."..." : $fprod->name); ?></a> </h6>
        </div>
        <?php if($gs->sign == 0): ?>
        <h4 class="mb-0 font-weight-semibold pricetxt"><?php echo e($curr->sign); ?><?php echo e(number_format($fprod->cprice, 2)); ?>

        <?php if($fprod->pprice != 0): ?>
        <del class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($fprod->pprice * $curr->value,2)); ?></del>
        <?php endif; ?>
        </h4>
        <?php else: ?>
        <h4 class="mb-0 font-weight-semibold">
        <?php echo e(round($fprod->cprice * $curr->value,2)); ?>

        <?php if($fprod->pprice != 0): ?>
        <del class="offer-price"><?php echo e($curr->sign); ?><?php echo e(round($fprod->pprice * $curr->value,2)); ?></del>
        <?php endif; ?>
        <?php echo e($curr->sign); ?>

        </h4>
        <?php endif; ?>

        <?php if($fprod->is_tier_price == 1): ?>
        <?php
        $tier_prices = json_decode($fprod->tier_prices,true);
        $total_t_prices = count($tier_prices);
        $lowestprice = min(array_column($tier_prices, 'price'));
        ?>
        <div class="text-muted mb-3">As Low As: <?php echo e($curr->sign); ?><?php echo e(number_format($lowestprice, 2)); ?></div>
        <?php endif; ?>

        <div class="row nomargin">
        <div class="col-lg-6"><button type="button"  data-productid="<?php echo e($fprod->id); ?>" class="btn bg-cart addajaxcart btn160widht mb-2"><i class="fa fa-cart-plus mr-2"></i> Add to cart</button></div>
        <div class="col-lg-6"><button type="button"  data-productid="<?php echo e($fprod->id); ?>" data-productsku="<?php echo e($fprod->sku); ?>" data-productname="<?php echo e($fprod->name); ?>" class="btn bg-cart btn160widht enqbtn mb-3" data-toggle="modal" data-target="#InquiryModal"><i class="fa fa-info"></i> Enquire Now</button></div>
        </div>

        </div>
        </div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
      </div>
    </div>
  </div>
</div>
<!--  Ending of product detail carousel area   -->
<?php /**PATH H:\wamp64\www\partzdeal\project\resources\views/includes/related-products.blade.php ENDPATH**/ ?>