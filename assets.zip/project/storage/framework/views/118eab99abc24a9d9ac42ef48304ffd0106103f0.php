      <?php
        $product_notff = App\Notification::where('product_id','!=',null)->get();
        if($product_notff->count() > 0){
          foreach($product_notff as $notf){
            $notf->is_read = 1;
            $notf->update();
          }
        }
      ?>   

                                                            <div class="profile-comments-title">
                                                                <h5>Products in low quantity.</h5>
                                                                <?php if($product_notff->count() > 0): ?>
                                                                <p  style="cursor: pointer;" id="product_clear">Clear All</p>
                                                                <?php endif; ?>
                                                            </div>

                                                            <?php if($product_notff->count() > 0): ?>
                                                            <?php $__currentLoopData = $product_notff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="single-comments-area">
                                                               <div class="comments-img">
                                                                    <img src="<?php echo e(asset('assets/images/'.$notf->product->photo)); ?>" alt="comments image">
                                                               </div>
                                                               <div class="single-comments-text">
                                                                   <h5><a href="<?php echo e(route('admin-prod-edit',$notf->product->id)); ?>" style="color: #333;"><?php echo e($notf->product->name > 30 ? substr($notf->product->name,0,30) : $notf->product->name); ?></a></h5>
                                                                   <p>Stock : <?php echo e($notf->product->stock); ?></p>
                                                               </div>
                                                               </div>
                                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            <div class="single-comments-area">
                                                            <h5>No Products in low quantity.</h5> 
                                                            </div>  
                                                            <?php endif; ?><?php /**PATH /home/partzdeal/public_html/project/resources/views/product_notf.blade.php ENDPATH**/ ?>