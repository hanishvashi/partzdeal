<form id="searchForm" class="search-form" action="" method="GET">
<div class="input-group has-search">
<input type="text" id="prod_name" name="search" class="form-control" placeholder="Search products">

<div class="input-group-append">
<a href="#" class="input-group-text form-control-feedback"><span class="fa fa-search"></span></a>
</div>
</div>
<div class="autocomplete" style="display:none;">
<div id="myInputautocomplete-list" class="autocomplete-items">
</div>
</div>
</form>
<?php /**PATH /home/partzdeal/public_html/project/resources/views/includes/autocomplete.blade.php ENDPATH**/ ?>