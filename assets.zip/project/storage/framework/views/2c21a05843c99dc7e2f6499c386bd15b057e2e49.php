
<?php $__env->startSection('content'); ?>

<!-- Starting of ViewCart area -->
    <div class="section-padding product-shoppingCart-wrapper pb-0">
        <div class="container">
            <div class="row">
              <div class="col-lg-12 text-center">
                <div class="view-cart-title">
                  <!--<a style="color:black;" href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>-->
                  <!--<i class="fa fa-angle-right"></i>-->
                  <!--<a style="color:black;" href="<?php echo e(route('front.cart')); ?>"><?php echo e(ucfirst(strtolower($lang->fht))); ?></a>-->
                  <h4>Your shopping cart</h4>
                </div>
              </div>
                <div class="col-md-12 col-sm-12">
                <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <div class="table-responsive pb-0 ">
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                          <th><?php echo e($lang->cimage); ?></th>
                          <th><?php echo e($lang->cproduct); ?></th>
                          <th><?php echo e($lang->cquantity); ?></th>
                          <th><?php echo e($lang->cupice); ?></th>
                          <!--<th><?php echo e($lang->cst); ?></th>-->
                          <th><!--<?php echo e($lang->cremove); ?>--></th>
                        </tr>
                      </thead>
                      <tbody>

                            <?php if(Session::has('cart')): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="del<?php echo e($product['item']['id']); ?>">
                            <td><img src="<?php echo e(asset('assets/images/'.$store_code.'/products/thumb_'.$product['item']['photo'])); ?>" class="img-fluid cart_img" alt="table image"></td>

                            <td>
                              <p class="product-name-header"><strong><a href="<?php echo e(route('front.page',['slug' => $product['item']['slug']])); ?>"><?php echo e($product['item']['name']); ?></a></strong></p>
                              <?php if($product['item']['size'] != null): ?>
							  <p>Size: <span class="ml-2"><?php echo e($product['size']); ?></span></p>
							  <?php endif; ?>
							  <?php if($product['item']['color'] != null): ?>
							  <p>Color: <span class="ml-2 optclrbg" style="background: <?php echo e($product['color']); ?>;">&nbsp;</span></p>
							  <?php endif; ?>
							  <!--<p class="table-product-review">-->
                                <!--<div class="ratings">-->
                                <!--    <div class="empty-stars"></div>-->
                                <!--    <div class="full-stars" style="width:<?php echo e(App\Review::ratings($product['item']['id'])); ?>%"></div>-->
                                <!--</div>-->
                                <?php
                                $prod =App\Product::findOrFail($product['item']['id']);

                                ?>
                                <!--<span>(<?php echo e(count($prod->reviews)); ?> <?php echo e($lang->dttl); ?>)</span>-->
                              <!--</p>-->
                            </td>

                            <td>
                              <div class="productDetails-quantity">
                                <!--<p><?php echo e($lang->cquantity); ?></p>-->
                                <span class="quantity-btn reducing"><i class="fa fa-minus"></i></span>
                                <span id="qty<?php echo e($product['item']['id']); ?>"><?php echo e($product['qty']); ?></span>
                                <input type="hidden" value="<?php echo e($product['item']['id']); ?>">
            					<input type="hidden" class="itemid" value="<?php echo e($product['item']['id']); ?>">
            					<?php if($product['item']['size'] != null): ?>
            					<input type="hidden" class="size_qty" value="<?php echo e($product['size_qty']); ?>">
            					<input type="hidden" class="size_price" value="<?php echo e($product['size_price']); ?>">
            					<input type="hidden" class="size_key" value="<?php echo e($product['size_key']); ?>">
            					<input type="hidden" class="size" value="<?php echo e($product['size']); ?>">
            					<?php else: ?>
            					<input type="hidden" class="size_qty" value=""/>
            					<input type="hidden" class="size_price" value=""/>
            					<input type="hidden" class="size_key" value=""/>
            					<input type="hidden" class="size" value=""/>
            					<?php endif; ?>
                                <span class="quantity-btn adding"><i class="fa fa-plus"></i></span>
                                
                              </div>
                            </td>
                            <td>
                              <?php if($gs->sign == 0): ?>
								<?php if($product['itemprice']==0): ?>
                              <?php echo e($curr->sign); ?><span id="itemprc<?php echo e($product['item']['id']); ?>"><?php echo e(number_format($product['item']['cprice'], 2)); ?></span>
								<?php else: ?>
							  <?php echo e($curr->sign); ?><span id="itemprc<?php echo e($product['item']['id']); ?>"><?php echo e(number_format($product['itemprice'], 2)); ?></span>
								<?php endif; ?>
                              <?php else: ?>
								<?php if($product['itemprice']==0): ?>
								<span id="itemprc<?php echo e($product['item']['id']); ?>"><?php echo e(number_format($product['item']['cprice'], 2)); ?></span> <?php echo e($curr->sign); ?>

								<?php else: ?>
								<span id="itemprc<?php echo e($product['item']['id']); ?>"><?php echo e(number_format($product['itemprice'], 2)); ?></span><?php echo e($curr->sign); ?>

								<?php endif; ?>
                              <?php endif; ?>

                            </td>
                            <!--<td>-->
                            <!--  <?php if($gs->sign == 0): ?>-->
                            <!--  <?php echo e($curr->sign); ?><span id="prc<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value, 2)); ?></span>-->
                            <!--  <?php else: ?>-->
                            <!--  <span id="prc<?php echo e($product['item']['id']); ?>"><?php echo e(round($product['price'] * $curr->value, 2)); ?></span><?php echo e($curr->sign); ?>-->
                            <!--  <?php endif; ?>-->
                            <!--</td>-->

                            <td><i class="fa fa-trash-o" aria-hidden="true" style="cursor: pointer;" onclick="remove(<?php echo e($product['item']['id']); ?>)"></i></td>
                            <input type="hidden" id="stock<?php echo e($product['item']['id']); ?>" value="<?php echo e($product['stock']); ?>">
                        </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                              <td colspan="5"><h2 class="text-center pt-5 pb-5"><?php echo e($lang->h); ?></h2></td>
                            </tr>
                            <?php endif; ?>
                      </tbody>
                      <tfoot>
                      <?php if(Session::has('cart')): ?>
                        <tr>
                          <td colspan="5" class="text-right">
                          <h5 class="d-inline-block m-0 mr-2"><?php echo e($lang->vt); ?>: </h5>
                          <h5 class="d-inline-block m-0">
                            <?php if($gs->sign == 0): ?>
                            <span class="total" id="grandtotal"><?php echo e($curr->sign); ?><?php echo e(number_format($totalPrice, 2)); ?></span>
                            <?php else: ?>
                            <span class="total" id="grandtotal"><?php echo e(number_format($totalPrice, 2)); ?></span><?php echo e($curr->sign); ?>

                            <?php endif; ?>
                          </h5>
                          </td>
                        </tr>
                      <?php endif; ?>
                        <tr>
                          <td colspan="5" class="text-right">
                            <a href="<?php echo e(route('front.index')); ?>" class="shopping-btn"><?php echo e($lang->ccs); ?></a>
                            <a href="<?php echo e(route('front.checkout')); ?>" class="update-shopping-btn"><?php echo e($lang->cpc); ?></a>
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>

                </div>
            </div>
        </div>
    </div>
    <!-- Ending of ViewCart area -->

    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
      $(document).on("click", ".adding" , function(){
        var pid =  $(this).parent().find('input[type=hidden]').val();
        var stck = $("#stock"+pid).val();
        var qty = $("#qty"+pid).html();
		var itemid = $(this).parent().parent().find('.itemid').val();
		var size_qty = $(this).parent().parent().find('.size_qty').val();
        var size_price = $(this).parent().parent().find('.size_price').val();
		var size_key = $(this).parent().parent().find('.size_key').val();
        if(stck != "")
        {
          var stk = parseInt(stck);
          if(qty <= stk)
          {
          qty++;
          $("#qty"+pid).html(qty);
          }
        }
        else{
         qty++;
         $("#qty"+pid).html(qty);
        }
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/addbyone')); ?>",
                    data:{id:pid,itemid:itemid,size_qty:size_qty,size_price:size_price},
                    success:function(data){
                        if(data == 0)
                        {
                        }
                        else
                        {
							console.log(data);
                        $(".total").html("<?php echo e($curr->sign); ?>"+(data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                        $(".cart-quantity").html(data[3]);
                        $("#cqty"+pid).val("1");
                        $("#prc"+pid).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                        $("#prct"+pid).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                        $("#cqt"+pid).html(data[1]);
                        $("#qty"+pid).html(data[1]);
						$("#itemprc"+pid).html(data[4]);
                        }
                      }
              });
       });

      $(document).on("click", ".reducing" , function(){
        var id =  $(this).parent().find('input[type=hidden]').val();
        var stck = $("#stock"+id).val();
        var qty = $("#qty"+id).html();
        qty--;
		var itemid = $(this).parent().parent().find('.itemid').val();
		var size_qty = $(this).parent().parent().find('.size_qty').val();
        var size_price = $(this).parent().parent().find('.size_price').val();
		var size_key = $(this).parent().parent().find('.size_key').val();
        if(qty < 1)
         {
         $("#qty"+id).html("1");
         }
         else{
         $("#qty"+id).html(qty);
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/reducebyone')); ?>",
                    data:{id:id,itemid:itemid,size_qty:size_qty,size_price:size_price},
                    success:function(data){
                        $(".total").html((data[0] * <?php echo e($curr->value); ?>).toFixed(2));
                        $(".cart-quantity").html(data[3]);
                        $("#cqty"+id).val("1");
                        $("#prc"+id).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                        $("#prct"+id).html((data[2] * <?php echo e($curr->value); ?>).toFixed(2));
                        $("#cqt"+id).html(data[1]);
                        $("#qty"+id).html(data[1]);
						$("#itemprc"+id).html(data[4]);
                      }
              });
         }
       });
</script>

<script type="text/javascript">
       $(document).on("click", ".delcart" , function(){
        $(this).parent().parent().hide();
       });
</script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/partzdeal/public_html/project/resources/views/front/cart.blade.php ENDPATH**/ ?>