<?php $__env->startSection('content'); ?>

    <div class="section-padding">
        <div class="container-fluid">
            <div class="row">
              <div class="col-12 col-md-4 col-lg-3 col-xl-3">
                 <?php echo $__env->make('includes.home-brand-filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               	<?php echo $__env->make('includes.home-catalog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               </div>
                <div class="col-12 col-md-8 col-lg-9 col-xl-9">
                <?php echo $page->text; ?>

                </div>
           </div>
       </div>
   </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\durapart\project\resources\views/front/page.blade.php ENDPATH**/ ?>