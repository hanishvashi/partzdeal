
<?php if($gs->hv == 1): ?>

<?php echo $__env->make('includes.featured-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('includes.top-rated-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/partzdeal/project/resources/views/front/extraindex.blade.php ENDPATH**/ ?>