<?php $__env->startSection('content'); ?>
<div class="section-padding product-shoppingCart-wrapper pb-0">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <div class="view-cart-title">
          <!--<a style="color:black;" href="<?php echo e(route('front.index')); ?>"><?php echo e(ucfirst(strtolower($lang->home))); ?></a>-->
          <!--<i class="fa fa-angle-right"></i>-->
          <!--<a style="color:black;" href="<?php echo e(route('front.cart')); ?>"><?php echo e(ucfirst(strtolower($lang->fht))); ?></a>-->
          <h4>Your Payment</h4>
        </div>
      </div>
      <div class="col-md-12 col-sm-12">
        <form action="<?php echo e($action); ?>" method="post" id="payuForm" name="payuForm"><br />
            <input type="hidden" name="key" value="<?php echo e($MERCHANT_KEY); ?>" /><br />
            <input type="hidden" name="hash" value="<?php echo e($hash); ?>"/><br />
            <input type="hidden" name="txnid" value="<?php echo e($txnid); ?>" /><br />
            <input type="hidden" name="amount" value="<?php echo e($total_amount); ?>" /><br />
            <input type="hidden" name="firstname" id="firstname" value="<?php echo e($full_name); ?>" /><br />
            <input type="hidden" name="email" id="email" value="<?php echo e($user_email); ?>" /><br />
            <input type="hidden" name="productinfo" value="<?php echo e($item_name); ?>"><br />
            <input type="hidden" name="surl" value="<?php echo e($surl); ?>" /><br />
            <input type="hidden" name="furl" value="<?php echo e($furl); ?>" /><br />
            <input type="hidden" name="service_provider" value="payu_paisa"  />
            <input type="hidden" name="udf1" value="<?php echo e($order_id); ?>" />
            <?php
            if(!$hash) { ?>
                <input type="submit" value="Submit" />
            <?php } ?>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
           payuForm.submit();
    }
    document.getElementById("payuForm").submit();
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/partzdeal/project/resources/views/payumoney/index.blade.php ENDPATH**/ ?>