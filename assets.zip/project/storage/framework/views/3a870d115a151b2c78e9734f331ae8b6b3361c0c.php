<div class="product-filter-option">
<!--<h2 class="filter-title"><?php echo e($lang->doci); ?></h2>-->
<h4 class="heading_three mb-4 pb-2 pt-2 pr-2 pl-2">Brands</h4>
<div class="brnad-side-filter">
  <ul style="direction: ltr;">
  <?php
  $x=0;
  ?>
  <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="<?php if($filterdata['manufacturer']==$brandrow->id){ echo 'brand_selected'; }?>">
  <a class="home_brand_sel" data-brandid="<?php echo e($brandrow->id); ?>" href="javascript:void(0)"><?php echo e($brandrow->brand_name); ?></a>
  </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
<form style="display:none;" method="post" action="<?php echo e(route('ajax-brand-filter')); ?>">
<?php echo e(csrf_field()); ?>

<div class="row justify-content-center">
  <input type="hidden" name="manufacturer" id="manufacturer" value="<?php echo $filterdata['manufacturer'];?>">
  <div class="col-12">
  <label for="seriesSelector">Select Series</label>
  <select id="seriesSelector" name="select_series" class="form-control">
<option value="">Select Series</option>
  <?php $__currentLoopData = $allseries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seriesrow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <option <?php if($filterdata['select_series']==$seriesrow->id){ echo 'selected'; }?> value="<?php echo e($seriesrow->id); ?>"><?php echo e($seriesrow->series_name); ?></option>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
  </div>
  <div class="col-12">
  <label for="categoriesSelector">Select Category</label>
  <select id="categoriesSelector" name="select_category" class="form-control">
  <option value="">Select Category</option>
  <?php if(!empty($allcategories)){ foreach($allcategories as $category){?>
  <option <?php if($filterdata['select_category']==$category->id){ echo 'selected'; }?> value="<?php echo $category->id;?>"><?php echo $category->cat_name;?></option>
  <?php }}?>
  </select>
  </div>
  <div class="col-12">
  <label for="subcategoriesSelector">Select Sub Category</label>
  <select id="subcategoriesSelector" name="select_sub_category" class="form-control">
  <option value="">Select Sub Category</option>
  <?php if(!empty($subcategories)){ foreach($subcategories as $subcategory){?>
  <option <?php if($filterdata['select_sub_category']==$subcategory->id){ echo 'selected'; }?> value="<?php echo $subcategory->id;?>"><?php echo $subcategory->cat_name;?></option>
  <?php }}?>
  </select>
  </div>
    </div>
<div class="row justify-content-center">
<div class="col-12">
<button type="button" onclick="AdvanceSearchfilter();" class="btn btn-warning float-right home_brand_btn">Search</button>
</div>
</div>
</form>
</div>
</div>
<?php echo $__env->make('includes.home-catalog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/partzdeal/public_html/project/resources/views/includes/brand-filter.blade.php ENDPATH**/ ?>