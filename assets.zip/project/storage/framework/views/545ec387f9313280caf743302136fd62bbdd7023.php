<div class="slider slider-for-mainphoto">
<figure class="view overlay rounded z-depth-1 main-img">
<div class="gal-item" data-src="<?php echo e(filter_var($product->photo, FILTER_VALIDATE_URL) ?$product->photo:asset('assets/images/products/'.$product->photo)); ?>">
<img class="img-fluid z-depth-1" src="<?php echo e(filter_var($product->photo, FILTER_VALIDATE_URL) ?$product->photo:asset('assets/images/products/'.$product->photo)); ?>" />
</div>
</figure>
<?php
if(!$product->galleries->isEmpty())
{
?>
<?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<figure class="view overlay rounded z-depth-1 main-img">
<div class="gal-item" data-src="<?php echo e(filter_var($gal->photo, FILTER_VALIDATE_URL) ?$gal->photo:asset('assets/images/products/gallery/'.$gal->photo)); ?>">
<img class="img-fluid z-depth-1" src="<?php echo e(filter_var($gal->photo, FILTER_VALIDATE_URL) ?$gal->photo:asset('assets/images/products/gallery/'.$gal->photo)); ?>" />
</div>
</figure>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php }?>

</div>

<div class="slider slider-nav-smallphoto">
<div class="sm-gal-item">
<a href="javascript:void(0)">
<img class="" width="80" src="<?php echo e(filter_var($product->photo, FILTER_VALIDATE_URL) ?$product->photo:asset('assets/images/products/'.$product->photo)); ?>" title="The description goes here">
</a>
</div>
<?php
if(!$product->galleries->isEmpty())
{
?>
<?php $__currentLoopData = $product->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="sm-gal-item">
<a href="javascript:void(0)">
<img width="80" src="<?php echo e(asset('assets/images/products/gallery/'.$gal->photo)); ?>" title="The description goes here">
</a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php }?>
</div>
<?php /**PATH H:\wamp64\www\durapart\project\resources\views/includes/product-gallery.blade.php ENDPATH**/ ?>