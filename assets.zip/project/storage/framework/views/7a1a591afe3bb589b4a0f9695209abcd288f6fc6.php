
<?php $__env->startSection('content'); ?>
<?php
$i=1;
$j=1;
?>


    <!-- Starting of product category area -->
	<div id="content" class="shopPage">
		<section id="shop_section" class="p-4">
      <div class="container-fluid">
        <div class="row justify-content-center">
          <div class="col-12 col-md-4 col-lg-3 col-xl-3">
						<?php echo $__env->make('includes.catalog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
					<?php if(isset($subcat)){
						$catinfo = $subcat;
					}else{
						$catinfo = $cat;
					}?>
					<input type="hidden" id="category_id" name="category_id" value="<?php echo $catinfo->id;?>">
          <div class="col-12 col-md-8 col-lg-9 col-xl-9">
            <div class="row">
              <div class="col-8 col-sm-7 col-lg-8 col-xl-9 align-self-center">
                <h4 class="heading_three"><?php echo e($catinfo->cat_name); ?> <span class="small"><?php echo e($total_product); ?> Results</span></h4>
								<p><?php echo e($catinfo->short_description); ?></p>
							</div>
              <div class="col-12 col-sm-5 col-lg-4 col-xl-3 align-self-center text-right">
					<select onchange="CatalogSearchfilter();" id="sortby" class="custom-select">
					<?php if($sort == "new"): ?>
					<option value="new" selected><?php echo e($lang->doe); ?></option>
					<?php else: ?>
					<option value="new"><?php echo e($lang->doe); ?></option>
					<?php endif; ?>
					<?php if($sort == "old"): ?>
					<option value="old" selected><?php echo e($lang->dor); ?></option>
					<?php else: ?>
					<option value="old"><?php echo e($lang->dor); ?></option>
					<?php endif; ?>
					<?php if($sort == "low"): ?>
					<option value="low" selected><?php echo e($lang->dopr); ?></option>
					<?php else: ?>
					<option value="low"><?php echo e($lang->dopr); ?></option>
					<?php endif; ?>
					<?php if($sort == "high"): ?>
					<option value="high" selected><?php echo e($lang->doc); ?></option>
					<?php else: ?>
					<option value="high"><?php echo e($lang->doc); ?></option>
					<?php endif; ?>
					</select>
              </div>
            </div>
						<?php if($total_product>0): ?>
            <div id="product_items_grid" class="row product_list">
							
							
							<?php echo $__env->make('includes.product-grid-items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							
            </div>

						<?php else: ?>
						<h3 class="text-center">Product Coming Soon</h3>
						<?php endif; ?>
						<div class="ajax-load text-center"><!-- Place at bottom of page --></div>
          </div>
        </div>
      </div>
    </section>


	</div>


    <!-- Ending of product category area -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	$(document).on("click", ".add_to_wish" , function(){
            var pid = $(this).data("pid"); //$("#pid").val();
            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/wish')); ?>",
                    data:{id:pid},
                    success:function(data){
                        if(data == 1)
                        {
                            $.notify("<?php echo e($gs->wish_success); ?>","success");
							/*setTimeout(function () {
							location.reload(true);
						}, 1000);*/
                        }
                        else {
                            $.notify("<?php echo e($gs->wish_error); ?>","error");
                        }
                      }
              });

            return false;
        });
	$('.removewish').click(function(){
			var pid = $(this).data("pid");

            $.ajax({
                    type: "GET",
                    url:"<?php echo e(URL::to('/json/removewish')); ?>",
                    data:{id:pid},
                    success:function(data){
        $.notify("<?php echo e($gs->wish_remove); ?>","success");
				setTimeout(function () {
				location.reload(true);
				}, 1000);
                      }
              });
        return false;
    });
</script>


<script type="text/javascript">
            $("#ex2").slider({});
        $("#ex2").on("slide", function(slideRange) {
            var totals = slideRange.value;
            var value = totals.toString().split(',');
            $("#price-min").val(value[0]);
            $("#price-max").val(value[1]);
        });
</script>

</script>


<script type="text/javascript">
  //var page = 0;
  /*jQuery(window).scroll(function() {
		var st = jQuery(window).scrollTop();

      if(jQuery(window).scrollTop() + jQuery(window).height() >= jQuery(document).height()) {
          page++;
          //loadMoreData(page);
      }

  });*/


  function loadMoreData(page){
    var category_id = $("#category_id").val();
		var sortby = $("#sortby").val();
		var pricemin =   $("#price-min").val();
		var pricemax = $("#price-max").val();
    jQuery.ajax({
              url:"<?php echo e(URL::to('/json/subcategoryfilterproductajax')); ?>",
              type: "POST",
              data: { "_token": "<?php echo e(csrf_token()); ?>",pricemin:pricemin,pricemax:pricemax,sortby:sortby,page:page, category_id:category_id, ajax: 'ajax'},
              beforeSend: function()
              {
								jQuery('.ajaxloadermodal').show();
              }
            })
          .done(function(data)
          {
            if( isEmpty(data) ) {
              jQuery(".ajax-load").show();
              jQuery('.ajax-load').html("No more items found");
            jQuery('.ajaxloadermodal').hide();
              return;
              }
							//console.log(data);
             jQuery('.ajaxloadermodal').hide();
              jQuery("#product_items_grid").html(data);
          })
          .fail(function(jqXHR, ajaxOptions, thrownError)
          {
            alert('server not responding...');
          });
  }
    function isEmpty(str){
    return !str.replace(/\s+/, '').length;
}

function CatalogSearchfilter()
{
	  var category_id = $("#category_id").val();
		var sortby = $("#sortby").val();
		var pricemin =   $("#price-min").val();
		var pricemax = $("#price-max").val();
		jQuery.ajax({
              url:"<?php echo e(URL::to('/json/subcategoryfilterproductajax')); ?>",
              type: "POST",
              data: { "_token": "<?php echo e(csrf_token()); ?>",pricemin:pricemin,pricemax:pricemax,sortby:sortby,page:1, category_id:category_id, ajax: 'ajax'},
              beforeSend: function()
              {
								jQuery('.ajaxloadermodal').show();
              }
            })
          .done(function(data)
          {
            if( isEmpty(data) ) {
              jQuery(".ajax-load").show();
              jQuery('.ajax-load').html("No items found");
            jQuery('.ajaxloadermodal').hide();
              return;
              }
							//console.log(data);
             jQuery('.ajaxloadermodal').hide();
              jQuery("#product_items_grid").html(data);
          })
          .fail(function(jqXHR, ajaxOptions, thrownError)
          {
            alert('server not responding...');
          });
}
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/partzdeal/public_html/project/resources/views/front/sub-category.blade.php ENDPATH**/ ?>