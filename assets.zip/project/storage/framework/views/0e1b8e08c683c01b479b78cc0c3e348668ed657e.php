


<?php $__env->startSection('content'); ?>

<div class="section-padding login-area-wrapper">
           <div class="container-fluid">
               <div class="row">
                 <div class="col-12 col-md-4 col-lg-3 col-xl-3">
                    <?php echo $__env->make('includes.home-brand-filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  	<?php echo $__env->make('includes.home-catalog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                   <div class="col-12 col-md-8 col-lg-9 col-xl-9">
                       <div class="login-area">
                           <h2 class="signIn-title text-center"><?php echo e($lang->contact); ?></h2>
                           <hr>
                           <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           <div class="login-form">
                             <form action="<?php echo e(route('front.contact.submit')); ?>" method="POST">
                                 <?php echo e(csrf_field()); ?>

                                 <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                                     <input class="form-control" name="name" placeholder="<?php echo e($lang->con); ?>" required="" type="text">
                                 </div>
                                 <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                                     <input class="form-control" name="phone" placeholder="<?php echo e($lang->cop); ?>" required="" type="tel">
                                 </div>
                                 <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                                     <input class="form-control" name="email" placeholder="<?php echo e($lang->coe); ?>" required="" type="email">
                                 </div>
                                 <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                                   <textarea class="form-control" name="text" id="comment" placeholder="<?php echo e($lang->cor); ?>" cols="30" rows="10" style="resize: vertical;" required=""></textarea>
                                   </div>

                                     <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                                         <?php if($lang->rtl == 1): ?>
                                         <div class="col-md-2 col-md-offset-6 col-sm-2 col-sm-offset-4 col-xs-2 col-xs-offset-4">
                                             <span style="cursor: pointer; float: right;" class="refresh_code"><i class="fa fa-refresh fa-2x" style="margin-top: 10px;"></i></span>
                                         </div>
                                         <div class="col-md-4 col-sm-6 col-xs-6">
                                             <img id="codeimg" src="<?php echo e(url('assets/images')); ?>/capcha_code.png">
                                         </div>
                                         <?php else: ?>
                                         <div class="col-md-4 col-sm-6 col-xs-6">
                                             <img id="codeimg" src="<?php echo e(url('assets/images')); ?>/capcha_code.png">
                                         </div>
                                         <div class="col-md-2 col-sm-2 col-xs-2">
                                             <span style="cursor: pointer;" class="refresh_code"><i class="fa fa-refresh fa-2x" style="margin-top: 10px;"></i></span>
                                         </div>
                                         <?php endif; ?>
                                     </div>

                                     <div class="form-group <?php echo e($lang->rtl == 1 ? 'text-right' : ''); ?>">
                                             <input class="form-control" name="codes" placeholder="<?php echo e($lang->enter_code); ?>" required="" type="text">
                                     </div>
                                     <div class="form-group">
                                       <input type="hidden" name="to" value="<?php echo e($ps->contact_email); ?>">
                                         <button type="submit" value="<?php echo e($lang->sm); ?>" class="btn btn_submit"><?php echo e($lang->sm); ?></button>
                                     </div>


                             </form>
                           </div>
                       </div>
                   </div>
               </div>
           </div>
       </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $('.refresh_code').click(function () {
            $.get('<?php echo e(url('contact/refresh_code')); ?>', function(data, status){
                $('#codeimg').attr("src","<?php echo e(url('assets/images')); ?>/capcha_code.png?time="+ Math.random());
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/partzdeal/public_html/project/resources/views/front/contact.blade.php ENDPATH**/ ?>