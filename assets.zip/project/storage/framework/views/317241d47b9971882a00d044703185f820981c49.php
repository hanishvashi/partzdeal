<option value="">Select State</option>
<?php if(Auth::guard('user')->check()): ?>
	<?php $__currentLoopData = $allstates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option value="<?php echo e($data->name); ?>" <?php echo e(Auth::guard('user')->user()->state == $data->name ? 'selected' : ''); ?>><?php echo e($data->name); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
	<?php $__currentLoopData = $allstates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option value="<?php echo e($data->name); ?>"><?php echo e($data->name); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/partzdeal/public_html/project/resources/views/load/states.blade.php ENDPATH**/ ?>