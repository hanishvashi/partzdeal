<?php $__env->startSection('content'); ?>

<div class="right-side">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <!-- Starting of Dashboard data-table area -->
                        <div class="section-padding add-product-1">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="add-product-box">
                                    <div class="product__header">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-6 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Orders</h2>
                                                    <p>Dashboard <i class="fa fa-angle-right" style="margin: 0 2px;"></i> Orders <i class="fa fa-angle-right" style="margin: 0 2px;"></i> All Orders</p>
                                                </div>
                                            </div>
                                              <?php echo $__env->make('includes.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        </div>   
                                    </div>
                  <div>
                                          <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                          <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
  <div class="col-sm-12">
                                    <div class="table-responsive">
                                      <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                                              <thead>
                                                  <tr>
                                                    <th style="width: 130px;">Customer Email</th>
                                                    <th style="width: 150px;">Invoice Number</th>
                                                    <th style="width: 90px;">Total Qty</th>
                                                    <th style="width: 100px;">Total Cost</th>
                                                    <th style="width: 160px;">Payment Method</th>
                                                    <th style="width: 380px;">Actions</th></tr>
                                              </thead>

                                              <tbody>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                  

                                                    <tr>
                                                    <td> <?php echo e($order->customer_email); ?></td>
                                                    <td> <a href="<?php echo e(route('admin-order-invoice',$order->id)); ?>"><?php echo e(sprintf("%'.08d", $order->id)); ?></a></td>
                                                    <td> <?php echo e($order->totalQty); ?></td>
                                                    <td> <?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></td>
                                                    <td> <?php echo e($order->method); ?></td>
                                                      <td>
                                                        <input type="hidden" value="<?php echo e($order->customer_email); ?>">
                                                        <a href="<?php echo e(route('admin-order-show',$order->id)); ?>" class="btn btn-primary product-btn"><i class="fa fa-check"></i> View Details</a>

                                                        <a style="cursor: pointer;" class="btn btn-success product-btn email"  data-toggle="modal" data-target="#emailModal"><i class="fa fa-send"></i> Send Email</a>


                                                        <span class="dropdown">
                                            <button class="btn btn-danger product-btn dropdown-toggle btn-xs" type="button" data-toggle="dropdown" style="font-size: 14px;
                                                        <?php if($order->status == "completed"): ?>
                                                        <?php echo e("background-color: #01c004;"); ?>

                                                        <?php elseif($order->status == "processing"): ?>
                                                        <?php echo e("background-color: #02abff;"); ?>

                                                        <?php elseif($order->status == "declined"): ?>
                                                        <?php echo e("background-color: #d9534f;"); ?>

                                                        <?php else: ?>
                                                        <?php echo e("background-color: #ff9600;"); ?>

                                                        <?php endif; ?>
                                                        
                                            "><?php echo e(ucfirst($order->status)); ?>

                                                <span class="caret"></span></button>
                                                        <ul class="dropdown-menu">
                                                            <li><a href="javascript:;" data-href="<?php echo e(route('admin-order-status',['id1' => $order->id, 'status' => 'processing'])); ?>" data-toggle="modal" data-target="#confirm-delete">Processing</a></li>
                                                            <li><a href="javascript:;" data-href="<?php echo e(route('admin-order-status',['id1' => $order->id, 'status' => 'completed'])); ?>" data-toggle="modal" data-target="#confirm-delete">Completed</a></li>
                                                            <li><a href="javascript:;" data-href="<?php echo e(route('admin-order-status',['id1' => $order->id, 'status' => 'declined'])); ?>" data-toggle="modal" data-target="#confirm-delete">Declined</a></li>
                                                        </ul>
                                                        </span>
                                                      </td>
                                                  </tr>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </tbody>
                                          </table></div></div>
                                        </div>
                                        </div>
                    </div>
                                  </div>
                              </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard data-table area -->
                </div>
            </div>
        </div>
    <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title text-center" id="myModalLabel">Update Order Status</h4>
                </div>
                <div class="modal-body">
                    <p class="text-center">Do you want to proceed?</p>
                </div>
                <div class="modal-footer" style="text-align: center;">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-success btn-ok">Proceed</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
        $('#confirm-delete').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\partzdeal\project\resources\views/admin/order/index.blade.php ENDPATH**/ ?>