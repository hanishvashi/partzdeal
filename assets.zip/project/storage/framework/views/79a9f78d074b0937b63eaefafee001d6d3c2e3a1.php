
<?php $__env->startSection('content'); ?>

        <!-- Starting of Account Dashboard area -->
    <div class="section-padding featured-product-wrap wow fadeInUp">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center" style="padding: 20px 0;">
                        <?php echo $gs->order_title; ?>

                        <?php echo $gs->order_text; ?>

                        <a href="<?php echo e(route('customer-orders')); ?>" style="text-transform: uppercase;" class="button style-10"><?php echo e($lang->fh); ?></a>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/partzdeal/public_html/project/resources/views/payreturn.blade.php ENDPATH**/ ?>