<?php if($gs->slider == 1): ?>
    <!--  Starting of homepage carousel area   -->
<section id="home_silder" class="">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
<?php
$i=1;
?>
<!-- Indicators -->
<!--<ol class="carousel-indicators">-->
<!--<li data-target="#bootstrap-touch-slider" data-slide-to="0" class="active"></li>-->
<!--<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sld): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
<!--<li data-target="#bootstrap-touch-slider" data-slide-to="<?php echo e($i++); ?>" class=""></li>-->
<!--<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
<!--</ol>-->
<!-- Wrapper For Slides -->
<div class="carousel-inner">
<div class="carousel-item active">
<img class="carousel_img d-block w-100" src="<?php echo e(asset('assets/images/'.$sls->photo)); ?>" alt="First slide">
</div>


<?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="carousel-item">
<img class="carousel_img d-block w-100" src="<?php echo e(asset('assets/images/'.$slider->photo)); ?>" alt="First slide">
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- End of Slide -->
</div><!-- End of Wrapper For Slides -->
</div>
</section>
    <!--  Ending of homepage carousel area   -->
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/partzdeal/project/resources/views/includes/banner-slider.blade.php ENDPATH**/ ?>