<?php $__env->startSection('content'); ?>
  <section class="customer-my-orders">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <!-- Starting of Dashboard data-table area -->
        <div class="section-padding add-product-1">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              <div class="add-product-box">
                                    <div class="product__header">
                                        <div class="row reorder-xs">
                                            <div class="col-lg-8 col-md-5 col-sm-5 col-xs-12">
                                                <div class="product-header-title">
                                                    <h2>Purchased Items</h2>
                                                </div>
                                            </div>
                                        </div>   
                                    </div>
                <div>
                  <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <div class="row">
                    <div class="col-sm-12">
                                    <div class="table-responsive">
                                      <table id="product-table_wrapper" class="table table-striped table-hover dt-responsive" cellspacing="0" width="100%">
                        <thead>
                        <tr class="table-header-row">
                          <th>Order#</th>
                          <th>Date</th>
                          <th>Order Total</th>
                          <th>Order Status</th>
                          <th>Details</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($order->order_number); ?></td>
                            <td><?php echo e(date('d M Y',strtotime($order->created_at))); ?></td>
                            <td><?php echo e($order->currency_sign); ?><?php echo e(round($order->pay_amount * $order->currency_value , 2)); ?></td>
                            <td><?php echo e(ucfirst($order->status)); ?></td>
                            <td><a href="<?php echo e(route('customer-order',$order->id)); ?>">View Order</a></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table></div></div>
                    </div>
					<div class="row">
    			<div class="col-md-12 text-center"> 
    			    <?php echo $orders->links(); ?>               
    			</div>
			</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Ending of Dashboard data-table area -->
    </div>
  </div>
  </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\wamp64\www\durapart\project\resources\views/user/customer-orders.blade.php ENDPATH**/ ?>