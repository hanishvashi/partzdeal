<!-- Classic tabs -->
<div class="classic-tabs border rounded mt-5 pt-1">

  <ul class="nav tabs-primary nav-justified" id="advancedTab" role="tablist">
    <li class="nav-item">
      <a class="nav-link active show" id="description-tab" data-toggle="tab" href="#description" role="tab" aria-controls="description" aria-selected="true">Description</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="info-tab" data-toggle="tab" href="#info" role="tab" aria-controls="info" aria-selected="false">Disclaimer</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" id="reviews-tab" data-toggle="tab" href="#reviews" role="tab" aria-controls="reviews" aria-selected="false">Reviews (<?php echo e(count($product->reviews)); ?>)</a>
    </li>
  </ul>
  <div class="tab-content" id="advancedTabContent">
    <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab">
      <h5>Product Description</h5>
      <p class="pt-1"><?php echo $product->description; ?></p>
    </div>
    <div class="tab-pane fade" id="info" role="tabpanel" aria-labelledby="info-tab">
      <h5>Disclaimer</h5>
      <p class="pt-1">Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam, sapiente illo. Sit
        error voluptas repellat rerum quidem, soluta enim perferendis voluptates laboriosam. Distinctio,
        officia quis dolore quos sapiente tempore alias.</p>
    </div>
    <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
      <h5>Product Reviews</h5>

      <?php if(Auth::guard('user')->check()): ?>

          <?php if(Auth::guard('user')->user()->orders()->count() > 0): ?>
          <h1 class="heading_three mb-4"><?php echo e($lang->fpr); ?></h1>
          <hr>
          <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="product-reviews">
              <div class="review-star">
                <div class='starrr' id='star1'></div>
                  <div>
                      <span class='your-choice-was' style='display: none;'>
                        <?php echo e($lang->dofpl); ?>: <span class='choice'></span>.
                      </span>
                  </div>
              </div>
          </div>
          <form class="product-review-form" action="<?php echo e(route('front.review.submit')); ?>" method="POST">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="user_id" value="<?php echo e(Auth::guard('user')->user()->id); ?>">
              <input type="hidden" name="rating" id="rate" value="5">
              <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
              <div class="form-group">
                  <textarea name="review" id="" rows="5" placeholder="<?php echo e($lang->suf); ?>" class="form-control" style="resize: vertical;" required></textarea>
              </div>
              <div class="form-group text-center">
                  <input name="btn" type="submit" class="btn-review" value="Submit Review">
              </div>
          </form>
          <?php else: ?>

          <?php endif; ?>
          <hr>
          <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="review-rating-description">
                  <div class="row">
                    <div class="col-md-3 col-sm-3">
                      <p><?php echo e($review->user->name); ?></p>
                      <p class="product-reviews">
                        <div class="ratings">
                          <div class="empty-stars"></div>
                          <div class="full-stars" style="width:<?php echo e($review->rating*20); ?>%"></div>
                        </div>
                      </p>
                      <p><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $review->review_date)->diffForHumans()); ?></p>
                    </div>
                    <div class="col-md-9 col-sm-9">
                      <p><?php echo e($review->review); ?></p>
                    </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="row">
                  <div class="col-md-12">
                      <h4><?php echo e($lang->md); ?></h4>
                  </div>
              </div>
              <?php endif; ?>

          <?php else: ?>

              <?php $__empty_1 = true; $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="review-rating-description">
                  <div class="row">
                    <div class="col-12 col-md-3">
                      <p><?php echo e($review->user->name); ?></p>
                      <p class="product-reviews">
                        <div class="ratings">
                          <div class="empty-stars"></div>
                          <div class="full-stars" style="width:<?php echo e($review->rating*20); ?>%"></div>
                        </div>
                    </p>
                      <p><?php echo e(Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $review->review_date)->diffForHumans()); ?></p>
                    </div>
                    <div class="col-12 col-md-9">
                      <p><?php echo e($review->review); ?></p>
                    </div>
                  </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="row">
                  <div class="col-md-12">
                      <h4><?php echo e($lang->md); ?></h4>
                  </div>
              </div>
          <?php endif; ?>
      <?php endif; ?>


    </div>
  </div>

</div>
<!-- Classic tabs -->
<?php /**PATH /home/partzdeal/public_html/project/resources/views/includes/product-detail-tabs.blade.php ENDPATH**/ ?>