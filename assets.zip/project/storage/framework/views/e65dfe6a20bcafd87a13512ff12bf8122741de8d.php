<option value="">Select Country</option>
<?php if(Auth::guard('user')->check()): ?>
	<?php $__currentLoopData = DB::table('countries')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option value="<?php echo e($data->name); ?>" <?php echo e(Auth::guard('user')->user()->country == $data->name ? 'selected' : ''); ?>><?php echo e($data->name); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
	<?php $__currentLoopData = DB::table('countries')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<option value="<?php echo e($data->name); ?>"><?php echo e($data->name); ?></option>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH H:\wamp64\www\partzdeal\project\resources\views/includes/countries.blade.php ENDPATH**/ ?>