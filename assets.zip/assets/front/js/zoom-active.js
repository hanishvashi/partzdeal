(function() {
    'use strict';

    //---------Product details zoom-----------
	if ($( window ).width() > 768) {			
		$('.product-zoom').zoom({ on:'click' });			
    }
        
})();